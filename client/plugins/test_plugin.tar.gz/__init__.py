from .foobar import TestPlugin
